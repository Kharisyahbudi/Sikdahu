#!/bin/bash
echo "=== SIKDAHU Setup ==="
echo "Installing dependencies..."
bun install
echo "Setting up database..."
bun run db:push
echo "Setup complete!"
echo "Run 'bun run dev' to start the application."
echo ""
echo "Default Login: admin / admin123"
