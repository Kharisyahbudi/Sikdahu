#!/bin/bash
echo "Setting up SIKDAHU..."
bun install
bun run db:push
echo "Setup complete! Run 'bun run dev' to start the application."
